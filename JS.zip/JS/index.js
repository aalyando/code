class Lable {
  constructor(text) {
    this.element = document.createElement("label");
    this.element.innerText = text;
  }
}

class Button {
  constructor(text, color = null) {
    this.element = document.createElement("button");
    this.element.innerText = text;
    if (color !== null) {
      this.element.style.color = color;
    }
  }
}

class Input {
  constructor(parent, { name, type, placeholder, value, label, min, max }) {
    this.element = document.createElement("input");
    this.element.name = name;
    this.element.type = type;
    this.element.placeholder = placeholder;
    this.element.value = value;
    this.element.id = name;
    if (label !== undefined) {
      label = new Lable(label.text);
      label.element.for = this.element.id;
      parent.appendChild(label.element);
    }
    if (name === "completed") {
      this.element.addEventListener("click", (e) => {
        let checkbox = this.element.checked;
        this.element.value = checkbox;
      });
    }
    if (min !== undefined && max !== undefined) {
      this.element.addEventListener("change", (e) => {
        if (
          this.element.value.length > max ||
          this.element.value.length < min
        ) {
          this.element.style.color = "red";
          this.element.value = `${name} just be more then ${min} and less then ${max}`;
        } else {
          this.element.style.color = "";
        }
      });

      this.element.addEventListener("focus", (e) => {
        if (this.element.style.color === "red") {
          this.element.style.color = "";
          this.element.value = "";
        }
      });
    }
    parent.appendChild(this.element);
  }
}

const setting = [
  {
    name: "userId",
    type: "number",
    placeholder: "enter userId",
    value: "",
    label: {
      text: "UserId"
    }
  },
  {
    name: "title",
    type: "text",
    placeholder: "Enter title for todos",
    value: "",
    max: 30,
    min: 2,
    label: {
      text: "Title"
    }
  },
  {
    name: "completed",
    type: "checkbox",
    value: "",
    label: {
      text: "Completed"
    }
  }
];

class todos {
  constructor(parent, todosData) {
    this.div = document.createElement("div");
    this.p = document.createElement("p");
    this.h1 = document.createElement("h1");
    this.btn = new Button("delete", "red");
    this.btnUpdateMod = new Button("update", "orange");
    this.btnSave = new Button("save", "green");
    this.p.innerText = todosData.completed;
    this.h1.innerText = todosData.title;

    this.inputH = new Input(parent, { value: this.h1.innerText, type: "text" });
    this.inputP = new Input(parent, { value: this.p.innerText, type: "text" });

    this.btnSave.element.style.display = "none";
    this.inputH.element.style.display = "none";
    this.inputP.element.style.display = "none";

    this.div.appendChild(this.h1);
    this.div.appendChild(this.p);

    this.div.appendChild(this.inputH.element);
    this.div.appendChild(this.inputP.element);

    this.div.appendChild(this.btn.element);
    this.div.appendChild(this.btnUpdateMod.element);
    this.div.appendChild(this.btnSave.element);

    if (parent.firstChild) {
      parent.insertBefore(this.div, parent.firstChild);
    } else {
      parent.appendChild(this.div);
    }

    this.btn.element.addEventListener("click", (e) => {
      $.ajax({
        url: `https://jsonplaceholder.typicode.com/todos/${todosData.id}`,
        method: "DELETE",
        success: () => parent.removeChild(this.div)
      });

      //fetch(`https://jsonplaceholder.typicode.com/todos/${todosData.id}`, {
      // method: "DELETE",
      //headers: {
      //  Accept: "application/json",
      //  "Content-Type": "application/json"
      // }
      //})
      // .then((response) => response.json())
      //.then((item) => parent.removeChild(this.div));
    });

    this.btnUpdateMod.element.addEventListener("click", (e) => {
      this.btnSave.element.style.display = "";
      this.inputH.element.style.display = "";
      this.inputP.element.style.display = "";

      this.btnUpdateMod.element.style.display = "none";
      this.p.style.display = "none";
      this.h1.style.display = "none";
      this.btn.element.style.display = "none";
    });

    this.btnSave.element.addEventListener("click", (e) => {
      $.ajax({
        url: `https://jsonplaceholder.typicode.com/todos/${todosData.id}`,
        method: "PATCH",

        data: {
          title: this.inputH.element.value,
          body: this.inputP.element.value
        },
        success: (todosData) => {
          this.p.innerText = todosData.body;
          this.h1.innerText = todosData.title;
          this.inputP.element.value = todosData.body;
          this.inputH.element.value = todosData.title;
        }
      })

        //fetch(`https://jsonplaceholder.typicode.com/todos/${todosData.id}`, {
        //method: "PATCH",
        //headers: {
        // Accept: "application/json",
        // "Content-Type": "application/json"
        //},
        //body: JSON.stringify({
        // title: this.inputH.element.value,
        // body: this.inputP.element.value
        //})
        //})
        .then((response) => response.json())
        .then((todosData) => {
          this.p.innerText = todosData.body;
          this.h1.innerText = todosData.title;
          this.inputP.element.value = todosData.body;
          this.inputH.element.value = todosData.title;
        });

      this.btnSave.element.style.display = "none";
      this.inputH.element.style.display = "none";
      this.inputP.element.style.display = "none";

      this.btnUpdateMod.element.style.display = "";
      this.p.style.display = "";
      this.h1.style.display = "";
      this.btn.element.style.display = "";
    });
  }
}

class Page {
  constructor(setting) {
    this.inputDiv = document.createElement("div");
    document.body.appendChild(this.inputDiv);

    this.outputDiv = document.createElement("div");
    document.body.appendChild(this.outputDiv);

    //fetch("https://jsonplaceholder.typicode.com/todos")
    //.then((response) => response.json())
    //.then((arr) => arr.map((item) => new todos(this.outputDiv, item)));

    $.ajax({
      url: "https://jsonplaceholder.typicode.com/todos",
      method: "GET",
      contentType: "application/json",
      success: (data) => data.map((item) => new todos(this.outputDiv, item))
    });
    this.button = new Button("submit");
    this.pageInputs = setting.map((item) => new Input(this.inputDiv, item));

    this.button.element.addEventListener("click", (e) => {
      if (this.pageInputs.find((item) => item.element.style.color === "red")) {
        return;
      }
      let data = this.pageInputs.reduce((acc, item) => {
        acc[item.element.name] = item.element.value;
        return acc;
      }, {});
      this.pageInputs.forEach((input) => {
        input.element.value = "";
      });

      $.ajax({
        url: 'https://jsonplaceholder.typicode.com/todos',
        method: "POST",
	data: data,
        success: (item) => new todos(this.outputDiv, item),
      })

      //fetch("https://jsonplaceholder.typicode.com/todos", {
      //method: "POST",
      //headers: {
      //Accept: "application/json",
      // "Content-Type": "application/json"
      // },
      // body: JSON.stringify(data)
      //})
      // .then((response) => response.json())
      // .then((item) => new todos(this.outputDiv, item));
      // });

      
    })
this.inputDiv.appendChild(this.button.element);
  }
}
window.addEventListener("load", function (event) {
  console.log("Loading of resources end!");
  new Page(setting);
});
